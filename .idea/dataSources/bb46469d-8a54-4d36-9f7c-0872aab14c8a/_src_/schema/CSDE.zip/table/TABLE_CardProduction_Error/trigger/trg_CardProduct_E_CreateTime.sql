create trigger "trg_CardProduct_E_CreateTime"
	before insert
	on TABLE_CardProduction_Error
	for each row
begin :new."CreateTime" := sysdate;  end;