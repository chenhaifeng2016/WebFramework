create trigger "trg_CardProduct_E_ModifyTime"
	before update
	on TABLE_CardProduction_Error
	for each row
begin :new."ModifyTime" := sysdate;  end;