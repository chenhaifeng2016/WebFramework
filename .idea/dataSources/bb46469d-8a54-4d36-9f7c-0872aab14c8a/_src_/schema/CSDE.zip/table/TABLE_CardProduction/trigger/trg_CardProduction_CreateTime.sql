create trigger "trg_CardProduction_CreateTime"
	before insert
	on TABLE_CardProduction
	for each row
begin :new."CreateTime" := sysdate;  end;