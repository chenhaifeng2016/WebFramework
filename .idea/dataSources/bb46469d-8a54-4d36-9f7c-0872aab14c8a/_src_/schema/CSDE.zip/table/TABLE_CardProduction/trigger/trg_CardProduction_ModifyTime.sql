create trigger "trg_CardProduction_ModifyTime"
	before update
	on TABLE_CardProduction
	for each row
begin :new."ModifyTime" := sysdate;  end;