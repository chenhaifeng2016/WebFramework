create trigger "trg_TaskDetail_ModifyTime"
	before update
	on TABLE_TaskDetail
	for each row
begin :new."ModifyTime" := sysdate;  end;