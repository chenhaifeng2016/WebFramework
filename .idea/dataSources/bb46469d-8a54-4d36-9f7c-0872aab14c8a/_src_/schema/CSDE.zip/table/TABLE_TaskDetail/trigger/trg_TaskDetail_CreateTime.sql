create trigger "trg_TaskDetail_CreateTime"
	before insert
	on TABLE_TaskDetail
	for each row
begin :new."CreateTime" := sysdate;  end;