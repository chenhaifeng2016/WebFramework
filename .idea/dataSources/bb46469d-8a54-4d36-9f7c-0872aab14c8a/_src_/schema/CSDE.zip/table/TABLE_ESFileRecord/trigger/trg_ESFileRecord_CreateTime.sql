create trigger "trg_ESFileRecord_CreateTime"
	before insert
	on TABLE_ESFileRecord
	for each row
begin :new."CreateTime" := sysdate;  end;