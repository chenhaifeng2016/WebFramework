create trigger "trg_IssueType_ModifyTime"
	before update
	on TABLE_IssueType
	for each row
begin :new."ModifyTime" := sysdate;  end;