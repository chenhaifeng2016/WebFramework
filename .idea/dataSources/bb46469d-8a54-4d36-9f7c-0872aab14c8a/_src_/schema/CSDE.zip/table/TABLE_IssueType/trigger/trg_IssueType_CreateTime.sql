create trigger "trg_IssueType_CreateTime"
	before insert
	on TABLE_IssueType
	for each row
begin :new."CreateTime" := sysdate;  end;