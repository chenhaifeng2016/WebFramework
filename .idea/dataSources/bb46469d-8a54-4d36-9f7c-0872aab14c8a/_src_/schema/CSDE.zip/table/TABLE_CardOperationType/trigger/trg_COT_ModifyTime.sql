create trigger "trg_COT_ModifyTime"
	before update
	on TABLE_CardOperationType
	for each row
begin :new."ModifyTime" := sysdate;  end;