create trigger "trg_COT_CreateTime"
	before insert
	on TABLE_CardOperationType
	for each row
begin :new."CreateTime" := sysdate;  end;