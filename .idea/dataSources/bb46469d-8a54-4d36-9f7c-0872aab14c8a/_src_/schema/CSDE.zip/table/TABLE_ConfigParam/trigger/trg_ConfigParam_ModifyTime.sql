create trigger "trg_ConfigParam_ModifyTime"
	before update
	on TABLE_ConfigParam
	for each row
begin :new."ModifyTime" := sysdate;  end;