create trigger "trg_ConfigParam_CreateTime"
	before insert
	on TABLE_ConfigParam
	for each row
begin :new."CreateTime" := sysdate;  end;