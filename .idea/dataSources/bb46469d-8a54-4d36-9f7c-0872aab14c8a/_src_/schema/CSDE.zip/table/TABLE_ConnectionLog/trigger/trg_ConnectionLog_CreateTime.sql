create trigger "trg_ConnectionLog_CreateTime"
	before insert
	on TABLE_ConnectionLog
	for each row
begin :new."CreateTime" := sysdate;  end;