create trigger "trg_TaskStatus_CreateTime"
	before insert
	on TABLE_TaskStatus
	for each row
begin :new."CreateTime" := sysdate;  end;