create trigger "trg_TaskStatus_ModifyTime"
	before update
	on TABLE_TaskStatus
	for each row
begin :new."ModifyTime" := sysdate;  end;