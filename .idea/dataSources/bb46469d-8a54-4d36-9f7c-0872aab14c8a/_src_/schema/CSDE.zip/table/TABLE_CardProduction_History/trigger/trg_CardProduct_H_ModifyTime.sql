create trigger "trg_CardProduct_H_ModifyTime"
	before update
	on TABLE_CardProduction_History
	for each row
begin :new."ModifyTime" := sysdate;  end;