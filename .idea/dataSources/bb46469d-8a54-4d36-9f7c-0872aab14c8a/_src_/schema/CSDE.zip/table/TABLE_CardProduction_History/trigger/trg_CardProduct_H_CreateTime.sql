create trigger "trg_CardProduct_H_CreateTime"
	before insert
	on TABLE_CardProduction_History
	for each row
begin :new."CreateTime" := sysdate;  end;