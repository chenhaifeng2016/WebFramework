create trigger "trg_ACCCL_H_CreateTime"
	before insert
	on TABLE_ACCCommLOG_History
	for each row
begin :new."CreateTime" := sysdate;  end;