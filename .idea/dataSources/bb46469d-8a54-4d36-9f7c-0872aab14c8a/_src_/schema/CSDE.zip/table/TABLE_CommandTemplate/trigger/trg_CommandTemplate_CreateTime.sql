create trigger "trg_CommandTemplate_CreateTime"
	before insert
	on TABLE_CommandTemplate
	for each row
begin :new."CreateTime" := sysdate;  end;