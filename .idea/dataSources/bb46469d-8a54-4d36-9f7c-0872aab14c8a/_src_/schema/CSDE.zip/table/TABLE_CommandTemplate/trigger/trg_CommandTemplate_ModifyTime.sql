create trigger "trg_CommandTemplate_ModifyTime"
	before update
	on TABLE_CommandTemplate
	for each row
begin :new."ModifyTime" := sysdate;  end;