create trigger "trg_CardType_CreateTime"
	before insert
	on TABLE_CardType
	for each row
begin :new."CreateTime" := sysdate;  end;