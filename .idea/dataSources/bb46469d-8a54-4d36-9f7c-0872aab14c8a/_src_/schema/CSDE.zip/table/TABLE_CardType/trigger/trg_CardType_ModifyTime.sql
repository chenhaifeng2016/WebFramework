create trigger "trg_CardType_ModifyTime"
	before update
	on TABLE_CardType
	for each row
begin :new."ModifyTime" := sysdate;  end;