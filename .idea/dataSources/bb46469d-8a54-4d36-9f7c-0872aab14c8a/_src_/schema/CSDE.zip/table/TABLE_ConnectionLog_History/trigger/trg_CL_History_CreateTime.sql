create trigger "trg_CL_History_CreateTime"
	before insert
	on TABLE_ConnectionLog_History
	for each row
begin :new."CreateTime" := sysdate;  end;