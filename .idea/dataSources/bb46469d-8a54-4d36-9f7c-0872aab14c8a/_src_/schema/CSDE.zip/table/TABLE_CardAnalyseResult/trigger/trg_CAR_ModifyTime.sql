create trigger "trg_CAR_ModifyTime"
	before update
	on TABLE_CardAnalyseResult
	for each row
begin :new."ModifyTime" := sysdate;  end;