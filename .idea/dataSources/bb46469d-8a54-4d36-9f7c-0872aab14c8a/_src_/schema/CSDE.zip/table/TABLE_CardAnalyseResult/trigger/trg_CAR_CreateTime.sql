create trigger "trg_CAR_CreateTime"
	before insert
	on TABLE_CardAnalyseResult
	for each row
begin :new."CreateTime" := sysdate;  end;