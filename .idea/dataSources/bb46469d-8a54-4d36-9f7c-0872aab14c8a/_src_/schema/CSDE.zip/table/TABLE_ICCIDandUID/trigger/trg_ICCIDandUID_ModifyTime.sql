create trigger "trg_ICCIDandUID_ModifyTime"
	before update
	on TABLE_ICCIDandUID
	for each row
begin :new."ModifyTime" := sysdate;  end;