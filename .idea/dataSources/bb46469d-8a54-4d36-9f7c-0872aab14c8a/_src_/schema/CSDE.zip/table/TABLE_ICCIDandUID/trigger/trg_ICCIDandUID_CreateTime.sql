create trigger "trg_ICCIDandUID_CreateTime"
	before insert
	on TABLE_ICCIDandUID
	for each row
begin :new."CreateTime" := sysdate;  end;