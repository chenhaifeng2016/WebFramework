create trigger "trg_TaskTotal_CreateTime"
	before insert
	on TABLE_TaskTotal
	for each row
begin :new."CreateTime" := sysdate;  end;