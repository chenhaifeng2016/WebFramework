create trigger "trg_TaskTotal_ModifyTime"
	before update
	on TABLE_TaskTotal
	for each row
begin :new."ModifyTime" := sysdate;  end;