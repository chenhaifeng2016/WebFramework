create trigger "trg_ACCCommLOG_CreateTime"
	before insert
	on TABLE_ACCCommLOG
	for each row
begin :new."CreateTime" := sysdate;  end;